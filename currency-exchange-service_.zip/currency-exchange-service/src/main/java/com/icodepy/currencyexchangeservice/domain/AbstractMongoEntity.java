package com.icodepy.currencyexchangeservice.domain;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Document
@Data
@EqualsAndHashCode(of="id")
public class AbstractMongoEntity<T> {

  @Id
  protected T id;
  
  @CreatedDate
  protected Date createdDate;
  
  @LastModifiedDate
  protected Date lastModifiedDate;
  
  @Indexed(unique=true, sparse=true)
  protected T customId;
  
  @SuppressWarnings("unchecked")
  public void copyentityFrom(AbstractMongoEntity<?> source) {
    this.id = (T) source.id;
    this.createdDate = source.createdDate;
    this.lastModifiedDate = source.lastModifiedDate;
    this.customId = (T) source.customId;
  }
  
}
