package com.icodepy.currencyexchangeservice;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;

@Configuration
@EnableMongoAuditing
public class MongoDBConfig {

  /*
  @Value("${spring.data.mongodb.host}")
  private String mongoHost;

  @Value("${spring.data.mongodb.port}")
  private int mongoPort;

  @Value("${spring.data.mongodb.database}")
  private String mongoDatabase;

  // Configure the MongoDB client

  @Bean
  public Mongo mongo() throws Exception {
    return new MongoClient(mongoHost, mongoPort);
  }

  @Bean
  public MongoTemplate mongoTemplate() throws Exception {
    return new MongoTemplate(mongoDbFactory(mongo()));
  }

  @Bean
  public MongoDbFactory mongoDbFactory(final Mongo mongo) throws Exception {
    return new MongoDbFactory(mongo, mongoDatabase);
  }*/

}
