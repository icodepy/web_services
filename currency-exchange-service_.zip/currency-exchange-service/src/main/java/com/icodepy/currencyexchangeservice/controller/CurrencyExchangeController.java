package com.icodepy.currencyexchangeservice.controller;

import java.math.BigDecimal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.icodepy.currencyexchangeservice.domain.ExchangeValue;
import com.icodepy.currencyexchangeservice.servieimpl.CurrencyExchangeService;

@RestController
public class CurrencyExchangeController {

  
  @Autowired
  private Environment environment;
  
  @Autowired
  private CurrencyExchangeService currencyExchange;
  
  @GetMapping("/currency-exchange/{from}/{to}")
  public ExchangeValue retrieveExchangeValue(@PathVariable String from, @PathVariable String to){
     //int port = Integer.parseInt(environment.getProperty("local.server.port"));
    return currencyExchange.getExchangeValue(from, to);
  }
  
  @PostMapping("/currency-exchange")
  public ExchangeValue createExchangeEntity(@RequestBody @Valid ExchangeValue exchangeValue) {
    return currencyExchange.saveExchangeValue(exchangeValue);
  }
}
