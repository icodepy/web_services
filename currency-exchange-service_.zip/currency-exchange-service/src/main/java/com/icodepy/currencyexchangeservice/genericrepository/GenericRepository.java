package com.icodepy.currencyexchangeservice.genericrepository;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface GenericRepository<T , S> extends MongoRepository<T,S>{

  T findByExfromAndExto(S exfrom, S exto);
  
}
