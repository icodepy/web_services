package com.icodepy.currencyexchangeservice.domain;

import java.math.BigDecimal;

import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=true)
public class ExchangeValue extends AbstractMongoEntity<Long>{

  @Id
  private Long id;  
  private String exfrom;
  private String exto;
  private BigDecimal conversionMultiple;
  private int port;
}
