package com.icodepy.currencyexchangeservice.servieimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icodepy.currencyexchangeservice.domain.ExchangeValue;
import com.icodepy.currencyexchangeservice.domainrepository.CurrencyExchangeRepository;
import com.icodepy.currencyexchangeservice.genericrepository.GenericRepository;

@Service
public class CurrencyExchangeService {
  
  @Autowired
  private CurrencyExchangeRepository repository;
  
  public GenericRepository domainRepository() {
    return repository;
  }
  
  public ExchangeValue saveExchangeValue(ExchangeValue exchangeValue) {
    exchangeValue = ExchangeValue.builder().exfrom(exchangeValue.getExfrom()).exto(exchangeValue.getExto())
                                  .conversionMultiple(exchangeValue.getConversionMultiple()).build();
    return repository.save(exchangeValue);
  }
  public ExchangeValue getExchangeValue(String exfrom, String exto) {
             return  repository.findByExfromAndExto(exfrom, exto);
  }

}
