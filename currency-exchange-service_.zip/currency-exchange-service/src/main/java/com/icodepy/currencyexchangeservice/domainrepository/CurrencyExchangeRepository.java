package com.icodepy.currencyexchangeservice.domainrepository;

import com.icodepy.currencyexchangeservice.domain.ExchangeValue;
import com.icodepy.currencyexchangeservice.genericrepository.GenericRepository;

public interface CurrencyExchangeRepository 
                                         extends GenericRepository<ExchangeValue, String>{
 
}
