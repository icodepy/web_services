package com.icodepy.currencyconversionservice.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.icodepy.currencyconversionservice.feignproxy.CurrencyExchangeServiceProxy;
import com.icodepy.currencyconversionservice.model.CurrencyConversion;
import com.icodepy.currencyconversionservice.service.CurrencyConversionService;

@RestController
public class CurrencyConversionController {

  @Autowired
  private CurrencyConversionService service;
  
  @Autowired
  private CurrencyExchangeServiceProxy cesProxy;
  
  @GetMapping("/currency-conversion/{from}/{to}/{quantity}")
  public CurrencyConversion getCalculatedAmount(@PathVariable String from, @PathVariable String to, @PathVariable BigDecimal quantity) {
    
    Map<String, String> map = new HashMap<>();
    map.put("from", from);
    map.put("to",to);
    
    ResponseEntity<CurrencyConversion> responseEntity = new RestTemplate().getForEntity("http://localhost:8000/currency-exchange/"+from+"/"+to
                                                                                                           , CurrencyConversion.class);   
    CurrencyConversion response = responseEntity.getBody();
    return service.getCalculatedAmount(response, quantity);
    
    
  }
  
  @GetMapping("/currency-conversion-feign/{from}/{to}/{quantity}")
  public CurrencyConversion getCalculatedAmountFeign(@PathVariable String from, @PathVariable String to, @PathVariable BigDecimal quantity) {
    
    /*
    Map<String, String> map = new HashMap<>();
    map.put("from", from);
    map.put("to",to);
    
    ResponseEntity<CurrencyConversion> responseEntity = new RestTemplate().getForEntity("http://localhost:8000/currency-exchange/"+from+"/"+to
                                                                                                           , CurrencyConversion.class);   
     */
    CurrencyConversion response = cesProxy.getCurrencyExchange(from, to);
    return service.getCalculatedAmount(response, quantity);
    
    
  }
}














