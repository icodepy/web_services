package com.icodepy.currencyconversionservice.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.icodepy.currencyconversionservice.model.CurrencyConversion;

@Service

public class CurrencyConversionService {

  
  public CurrencyConversion getCalculatedAmount(CurrencyConversion currencyConversion, BigDecimal quantity) {
    currencyConversion.setQuantity(quantity);
    currencyConversion.setTotalCalculatedAmount( currencyConversion.getExchangeMultiple().multiply(currencyConversion.getQuantity()));
    return currencyConversion;
  }
}
