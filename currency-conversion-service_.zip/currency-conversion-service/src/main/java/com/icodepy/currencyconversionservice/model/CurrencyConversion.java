package com.icodepy.currencyconversionservice.model;

import java.math.BigDecimal;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CurrencyConversion {

  @Id
  private String id;
  private String from;
  private String to;
  private int port;
  private BigDecimal exchangeMultiple;
  private BigDecimal quantity;
  private BigDecimal totalCalculatedAmount;
}
